# cucumberWithoutMavenHandsOn
This repositroy contains cuucmber example with plain Java.
