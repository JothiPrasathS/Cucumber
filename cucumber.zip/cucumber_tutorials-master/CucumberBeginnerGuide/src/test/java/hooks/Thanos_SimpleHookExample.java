package hooks;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Thanos_SimpleHookExample {

	/*@Before
	public void beforeScenario(){
		System.out.println("Thanos collects the Infinity stone");
	}

	@After
	public void afterScenario(){
		System.out.println("After Destroying everything takes rest in the garden");
	}*/

}


