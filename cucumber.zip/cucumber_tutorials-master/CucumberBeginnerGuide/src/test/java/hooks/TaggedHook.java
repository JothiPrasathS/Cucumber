package hooks;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class TaggedHook {

	/*@Before
	public void beforeScenario(){
		System.out.println("This will run before the every Scenario");
	}

	@After
	public void afterScenario(){
		System.out.println("This will run after the every Scenario");
	}

	@Before("@First,@Second")
	public void beforeFirstAndSecond(){
		System.out.println("This will run only before the First and second Scenario");
	} 

	@Before("@Second")
	public void beforeSecond(){
		System.out.println("This will run only before the Second Scenario");
	} 

	@Before("@Third")
	public void beforeThird(){
		System.out.println("This will run only before the Third Scenario");
	}

	@After("@First,@Second")
	public void afterFirstAndSecond(){
		System.out.println("This will run only after the First and Second Scenario");   
	} 

	

	@After("@Third")
	public void afterThird(){
		System.out.println("This will run only after the Third Scenario");   
	} */
}
